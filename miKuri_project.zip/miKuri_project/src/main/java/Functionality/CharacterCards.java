package Functionality;

import Cards.Card;
import javafx.scene.image.ImageView;

public interface CharacterCards {
    //kartlarda bulunması gereken ögeleri barındırıp alt sınıflarına miras bırakır
    void cardToStage(Card card, double x, double y);

    void removeCardFromStage(ImageView cardImage);

    void checkWin();
}
