package Functionality;

import java.io.IOException;

public interface MikuriMenuFunctionality {
    //menü için lazım olan metotları alt sınıflarına miras bırakır
    void onSlider();

    void onNewGameButtonClick();

    void onExitGameButtonClick();

    void menuBack() throws IOException;

    void setCredits();

    void gameDegisme() throws IOException;
}

