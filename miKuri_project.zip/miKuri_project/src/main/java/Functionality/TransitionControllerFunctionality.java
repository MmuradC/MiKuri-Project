package Functionality;

import java.io.IOException;

public abstract class TransitionControllerFunctionality {
    //alt sınıflara bu metotların uygulanması
    public abstract void menuyeDegisme() throws IOException;

    public abstract void automaticIncrease() throws InterruptedException;
}

