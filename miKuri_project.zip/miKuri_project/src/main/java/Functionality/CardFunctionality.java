package Functionality;

public abstract class CardFunctionality {
    //kart mekaniklerini alt sınıflarına miras bırakır
    public abstract String getName();

    public abstract int getHp();

    public abstract void setHp(int hp);

    public abstract String getType();

    public abstract int getAttacks();

    public abstract String toString();
}